<?php 

include "../../../config/koneksi.php";

//cek asal notice
$inap = (isset($_POST[notice]))? "AND rawat_inap IS NOT NULL" : "";
$isinap = (isset($_POST[notice]))? "1" : "NULL";
$k = mysql_num_rows(mysql_query("SELECT * FROM noticelab WHERE id_pasien='$_POST[id]' AND no_faktur='$_POST[nofak]' $inap"));

if($k > 0){
    $return = "Perintah sudah pernah dikirim";
} else {
    $return = "Perintah pemeriksaan lab berhasil dikirim";
    $r = $_POST[tarif];
    $rs = $_POST[jamin];
    foreach($r as $key => $val){
        mysql_query("INSERT INTO noticelab VALUES (NULL,'$_POST[nofak]','$_POST[id]','$_POST[dr]',NOW(),$isinap,'$val','$rs[$key]')");
    }
   }


?>
<script>
alert("<?php echo $return; ?>");
location.href="../../media.php?module=home";
</script>

<?php  ?>